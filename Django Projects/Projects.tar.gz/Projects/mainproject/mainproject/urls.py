
from django.contrib import admin
from django.urls import path, include
from polls import views
#from django.conf.urls import url, include

urlpatterns = [
    path('polls/', include('polls.urls')),
    path('admin/', admin.site.urls), 
    path('contact', views.contact, name='contact'),
    path('Aboutus', views.Aboutus, name='Aboutus'),
]